﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º  número", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach(int x in vetor)
            {
                auxiliar += x +"\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList minhaLista = new ArrayList()
            { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro"};
            minhaLista.Remove("Otávio");
            string auxiliar = "";
            foreach(string nomes in minhaLista)
            {
                auxiliar+= nomes +"\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[20, 3];
            string auxiliar = "";
            for ( int i = 0; i < 20; i++ )
                for(int j = 0; j < 3; j++ )
            {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}º  nota do aluno {i + 1}.", "Entrada de Dados");
                    if (!double.TryParse(auxiliar, out vetor[i,j]) || (vetor[i,j] < 0) || vetor[i,j] > 10)
                    {
                        MessageBox.Show("Número Inválido");
                        i--;
                    }
                }
            
        }
    }
}
