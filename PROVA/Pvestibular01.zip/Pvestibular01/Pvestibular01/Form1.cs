﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        int totalCurso1 = 0 , totalCurso2 = 0, totalCurso3= 0, totalGeral = 0;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lboxResult.ClearSelected();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[3, 5];
            string auxiliar = "";
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a quantidade de alunos do curso {i + 1} do ano {j + 1}.", "entrada de dados");

                    if (string.IsNullOrEmpty(auxiliar))
                    {
                        MessageBox.Show("Entrada invalida.");
                        break;
                    }
                    else if (!int.TryParse(auxiliar, out vetor[i, j]) || vetor[i, j] < 0)
                    {
                        MessageBox.Show("Numero Invalido");
                    }
                    else if (i == 0)
                    {
                        totalCurso1 = totalCurso1 + vetor[i, j];
                    }
                    else if (i == 1)
                    {
                        totalCurso2 = totalCurso2 + vetor[i, j];
                    }
                    else if (i == 2)
                    {
                        totalCurso3 = totalCurso3 + vetor[i, j];
                    }
                }
            }

            for (int a = 0; a < 5; a++)
            {
                lboxResult.Items.Add($"Total do curso 1 do ano {a + 1}: {vetor[0, a]}\n");
            }
            lboxResult.Items.Add($"Total curso 1: {totalCurso1}");
            lboxResult.Items.Add("_________________________");

            for (int b = 0; b < 5; b++)
            {
                lboxResult.Items.Add($"Total do curso 2 do ano {b + 1}: {vetor[1, b]}\n");
            }
            lboxResult.Items.Add($"Total curso 2: {totalCurso2}");
            lboxResult.Items.Add("_________________________");

            for (int c = 0; c < 5; c++)
            {
                lboxResult.Items.Add($"Total do curso 3 do ano {c + 1}: {vetor[2, c]}\n");
            }
            lboxResult.Items.Add($"Total curso 3: {totalCurso3}");
            lboxResult.Items.Add("_________________________");

            totalGeral = totalCurso1 + totalCurso2 + totalCurso3;
            lboxResult.Items.Add($"Total Geral: {totalGeral}");

            totalCurso1 = 0;
            totalCurso2 = 0;
            totalCurso3 = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
