﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace PContato0030482413017
{
    public partial class FrmPrincipal : Form
    {
        public static SqlConnection conexao;
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source = MIGUELSNOTE; Initial Catalog = LP2; Integrated Security = True; Pooling = False");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir banco de dados"+ex.Message);
            }
        }

        private void cadastrosContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmContato"];

            if (fc != null)
                fc.Close();

            frmContato FRMC = new frmContato();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSobre frmSobre = new FrmSobre();
            frmSobre.MdiParent = this;
            frmSobre.WindowState = FormWindowState.Maximized;
            frmSobre.Show();
        }
    }
}
