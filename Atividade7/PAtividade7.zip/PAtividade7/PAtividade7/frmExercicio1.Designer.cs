﻿namespace PAtividade7
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEsp = new System.Windows.Forms.Button();
            this.btnLR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rchtxtFrase.Location = new System.Drawing.Point(136, 49);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(559, 286);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnEsp
            // 
            this.btnEsp.BackColor = System.Drawing.Color.LightBlue;
            this.btnEsp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEsp.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEsp.Location = new System.Drawing.Point(37, 368);
            this.btnEsp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEsp.Name = "btnEsp";
            this.btnEsp.Size = new System.Drawing.Size(228, 64);
            this.btnEsp.TabIndex = 1;
            this.btnEsp.Text = "Quantidade de espaço em branco";
            this.btnEsp.UseVisualStyleBackColor = false;
            this.btnEsp.Click += new System.EventHandler(this.btnFor_Click);
            // 
            // btnLR
            // 
            this.btnLR.BackColor = System.Drawing.Color.LightBlue;
            this.btnLR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLR.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLR.Location = new System.Drawing.Point(306, 368);
            this.btnLR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLR.Name = "btnLR";
            this.btnLR.Size = new System.Drawing.Size(228, 64);
            this.btnLR.TabIndex = 2;
            this.btnLR.Text = "Quantidade de Letras R";
            this.btnLR.UseVisualStyleBackColor = false;
            this.btnLR.Click += new System.EventHandler(this.btnLR_Click);
            // 
            // btnPar
            // 
            this.btnPar.BackColor = System.Drawing.Color.LightBlue;
            this.btnPar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPar.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPar.Location = new System.Drawing.Point(570, 368);
            this.btnPar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(228, 64);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Pares de letras";
            this.btnPar.UseVisualStyleBackColor = false;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(384, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "Texto";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(862, 454);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLR);
            this.Controls.Add(this.btnEsp);
            this.Controls.Add(this.rchtxtFrase);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEsp;
        private System.Windows.Forms.Button btnLR;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.Label label1;
    }
}