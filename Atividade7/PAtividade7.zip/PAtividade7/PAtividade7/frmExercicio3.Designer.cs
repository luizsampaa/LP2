﻿namespace PAtividade7
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerif = new System.Windows.Forms.Button();
            this.lbltxt = new System.Windows.Forms.Label();
            this.txtFrase = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnVerif
            // 
            this.btnVerif.BackColor = System.Drawing.Color.LightBlue;
            this.btnVerif.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerif.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerif.Location = new System.Drawing.Point(253, 287);
            this.btnVerif.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVerif.Name = "btnVerif";
            this.btnVerif.Size = new System.Drawing.Size(311, 70);
            this.btnVerif.TabIndex = 5;
            this.btnVerif.Text = "Verificar palíndromo";
            this.btnVerif.UseVisualStyleBackColor = false;
            this.btnVerif.Click += new System.EventHandler(this.btnVerif_Click);
            // 
            // lbltxt
            // 
            this.lbltxt.AutoSize = true;
            this.lbltxt.BackColor = System.Drawing.Color.LightBlue;
            this.lbltxt.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltxt.Location = new System.Drawing.Point(328, 100);
            this.lbltxt.Name = "lbltxt";
            this.lbltxt.Size = new System.Drawing.Size(163, 27);
            this.lbltxt.TabIndex = 4;
            this.lbltxt.Text = "Digite o texto: ";
            // 
            // txtFrase
            // 
            this.txtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrase.Location = new System.Drawing.Point(194, 192);
            this.txtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(410, 38);
            this.txtFrase.TabIndex = 3;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVerif);
            this.Controls.Add(this.lbltxt);
            this.Controls.Add(this.txtFrase);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerif;
        private System.Windows.Forms.Label lbltxt;
        private System.Windows.Forms.TextBox txtFrase;
    }
}