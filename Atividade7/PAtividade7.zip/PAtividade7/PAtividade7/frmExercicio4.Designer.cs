﻿namespace PAtividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerifS = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblM = new System.Windows.Forms.Label();
            this.txtM = new System.Windows.Forms.TextBox();
            this.lblP = new System.Windows.Forms.Label();
            this.txtP = new System.Windows.Forms.TextBox();
            this.lblS = new System.Windows.Forms.Label();
            this.txtS = new System.Windows.Forms.TextBox();
            this.txtG = new System.Windows.Forms.TextBox();
            this.lblG = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVerifS
            // 
            this.btnVerifS.BackColor = System.Drawing.Color.LightBlue;
            this.btnVerifS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerifS.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifS.Location = new System.Drawing.Point(430, 325);
            this.btnVerifS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVerifS.Name = "btnVerifS";
            this.btnVerifS.Size = new System.Drawing.Size(311, 70);
            this.btnVerifS.TabIndex = 8;
            this.btnVerifS.Text = "Salario Bruto";
            this.btnVerifS.UseVisualStyleBackColor = false;
            this.btnVerifS.Click += new System.EventHandler(this.btnVerifS_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.LightBlue;
            this.lblNome.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(45, 45);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(86, 27);
            this.lblNome.TabIndex = 7;
            this.lblNome.Text = "Nome: ";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(221, 46);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(430, 38);
            this.txtNome.TabIndex = 6;
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.BackColor = System.Drawing.Color.LightBlue;
            this.lblM.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblM.Location = new System.Drawing.Point(45, 95);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(120, 27);
            this.lblM.TabIndex = 10;
            this.lblM.Text = "Matricula: ";
            // 
            // txtM
            // 
            this.txtM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtM.Location = new System.Drawing.Point(221, 96);
            this.txtM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtM.Name = "txtM";
            this.txtM.Size = new System.Drawing.Size(165, 38);
            this.txtM.TabIndex = 9;
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.BackColor = System.Drawing.Color.LightBlue;
            this.lblP.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP.Location = new System.Drawing.Point(42, 144);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(119, 27);
            this.lblP.TabIndex = 12;
            this.lblP.Text = "Produção: ";
            // 
            // txtP
            // 
            this.txtP.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP.Location = new System.Drawing.Point(221, 145);
            this.txtP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(165, 38);
            this.txtP.TabIndex = 11;
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.BackColor = System.Drawing.Color.LightBlue;
            this.lblS.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblS.Location = new System.Drawing.Point(45, 201);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(93, 27);
            this.lblS.TabIndex = 14;
            this.lblS.Text = "Salário: ";
            // 
            // txtS
            // 
            this.txtS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtS.Location = new System.Drawing.Point(221, 202);
            this.txtS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(165, 38);
            this.txtS.TabIndex = 13;
            // 
            // txtG
            // 
            this.txtG.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtG.Location = new System.Drawing.Point(221, 255);
            this.txtG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtG.Name = "txtG";
            this.txtG.Size = new System.Drawing.Size(165, 38);
            this.txtG.TabIndex = 15;
            // 
            // lblG
            // 
            this.lblG.AutoSize = true;
            this.lblG.BackColor = System.Drawing.Color.LightBlue;
            this.lblG.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblG.Location = new System.Drawing.Point(45, 262);
            this.lblG.Name = "lblG";
            this.lblG.Size = new System.Drawing.Size(144, 27);
            this.lblG.TabIndex = 18;
            this.lblG.Text = "Gratificação: ";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblG);
            this.Controls.Add(this.txtG);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.lblP);
            this.Controls.Add(this.txtP);
            this.Controls.Add(this.lblM);
            this.Controls.Add(this.txtM);
            this.Controls.Add(this.btnVerifS);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerifS;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.TextBox txtM;
        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.Label lblG;
    }
}