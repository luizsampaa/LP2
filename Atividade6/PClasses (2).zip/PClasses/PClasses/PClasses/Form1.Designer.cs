﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMen = new System.Windows.Forms.Button();
            this.btnHor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMen
            // 
            this.btnMen.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnMen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMen.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMen.Location = new System.Drawing.Point(429, 304);
            this.btnMen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMen.Name = "btnMen";
            this.btnMen.Size = new System.Drawing.Size(242, 143);
            this.btnMen.TabIndex = 0;
            this.btnMen.Text = "Mensalista";
            this.btnMen.UseVisualStyleBackColor = false;
            this.btnMen.Click += new System.EventHandler(this.btnMen_Click);
            // 
            // btnHor
            // 
            this.btnHor.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnHor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHor.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHor.Location = new System.Drawing.Point(429, 111);
            this.btnHor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHor.Name = "btnHor";
            this.btnHor.Size = new System.Drawing.Size(242, 144);
            this.btnHor.TabIndex = 1;
            this.btnHor.Text = "Horista";
            this.btnHor.UseVisualStyleBackColor = false;
            this.btnHor.Click += new System.EventHandler(this.btnHor_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnHor);
            this.Controls.Add(this.btnMen);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMen;
        private System.Windows.Forms.Button btnHor;
    }
}

