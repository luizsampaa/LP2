﻿namespace PClasses
{
    partial class frmHorarista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIH = new System.Windows.Forms.Button();
            this.lblNH = new System.Windows.Forms.Label();
            this.lblSH = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMa = new System.Windows.Forms.Label();
            this.txtNH = new System.Windows.Forms.TextBox();
            this.txtSH = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMA = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtDF = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.lblF = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIH
            // 
            this.btnIH.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnIH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIH.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIH.Location = new System.Drawing.Point(531, 345);
            this.btnIH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnIH.Name = "btnIH";
            this.btnIH.Size = new System.Drawing.Size(233, 68);
            this.btnIH.TabIndex = 18;
            this.btnIH.Text = "Instanciar Horista";
            this.btnIH.UseVisualStyleBackColor = false;
            this.btnIH.Click += new System.EventHandler(this.btnIH_Click);
            // 
            // lblNH
            // 
            this.lblNH.AutoSize = true;
            this.lblNH.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblNH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblNH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNH.Location = new System.Drawing.Point(24, 207);
            this.lblNH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNH.Name = "lblNH";
            this.lblNH.Size = new System.Drawing.Size(168, 25);
            this.lblNH.TabIndex = 17;
            this.lblNH.Text = "Numero De Horas";
            // 
            // lblSH
            // 
            this.lblSH.AutoSize = true;
            this.lblSH.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblSH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblSH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSH.Location = new System.Drawing.Point(24, 156);
            this.lblSH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSH.Name = "lblSH";
            this.lblSH.Size = new System.Drawing.Size(153, 25);
            this.lblSH.TabIndex = 16;
            this.lblSH.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblNome.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(24, 106);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(64, 25);
            this.lblNome.TabIndex = 15;
            this.lblNome.Text = "Nome";
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblMa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblMa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa.Location = new System.Drawing.Point(24, 60);
            this.lblMa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(91, 25);
            this.lblMa.TabIndex = 14;
            this.lblMa.Text = "Matricula";
            // 
            // txtNH
            // 
            this.txtNH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNH.Location = new System.Drawing.Point(343, 207);
            this.txtNH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNH.Name = "txtNH";
            this.txtNH.Size = new System.Drawing.Size(119, 30);
            this.txtNH.TabIndex = 13;
            // 
            // txtSH
            // 
            this.txtSH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSH.Location = new System.Drawing.Point(343, 156);
            this.txtSH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSH.Name = "txtSH";
            this.txtSH.Size = new System.Drawing.Size(119, 30);
            this.txtSH.TabIndex = 12;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(343, 109);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(345, 30);
            this.txtNome.TabIndex = 11;
            // 
            // txtMA
            // 
            this.txtMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMA.Location = new System.Drawing.Point(343, 55);
            this.txtMA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMA.Name = "txtMA";
            this.txtMA.Size = new System.Drawing.Size(119, 30);
            this.txtMA.TabIndex = 10;
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData.Location = new System.Drawing.Point(343, 257);
            this.txtData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(275, 30);
            this.txtData.TabIndex = 20;
            // 
            // txtDF
            // 
            this.txtDF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDF.Location = new System.Drawing.Point(343, 307);
            this.txtDF.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDF.Name = "txtDF";
            this.txtDF.Size = new System.Drawing.Size(119, 30);
            this.txtDF.TabIndex = 21;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(24, 257);
            this.lblData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(266, 25);
            this.lblData.TabIndex = 23;
            this.lblData.Text = "Data de Entrada Na Empresa";
            // 
            // lblF
            // 
            this.lblF.AutoSize = true;
            this.lblF.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF.Location = new System.Drawing.Point(24, 307);
            this.lblF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblF.Name = "lblF";
            this.lblF.Size = new System.Drawing.Size(136, 25);
            this.lblF.TabIndex = 22;
            this.lblF.Text = "Dias de Faltas";
            // 
            // frmHorarista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblF);
            this.Controls.Add(this.txtDF);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.btnIH);
            this.Controls.Add(this.lblNH);
            this.Controls.Add(this.lblSH);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMa);
            this.Controls.Add(this.txtNH);
            this.Controls.Add(this.txtSH);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMA);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmHorarista";
            this.Text = "frmHorarista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnIH;
        private System.Windows.Forms.Label lblNH;
        private System.Windows.Forms.Label lblSH;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtNH;
        private System.Windows.Forms.TextBox txtSH;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMA;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtDF;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblF;
    }
}