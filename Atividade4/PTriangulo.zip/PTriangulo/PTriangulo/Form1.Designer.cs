﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            btnExecuta = new Button();
            btnSair = new Button();
            txtLadoA = new TextBox();
            txtLadoB = new TextBox();
            txtLadoC = new TextBox();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Location = new Point(70, 67);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(94, 25);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Valor de A";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Location = new Point(74, 138);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(92, 25);
            lblLadoB.TabIndex = 1;
            lblLadoB.Text = "Valor de B";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Location = new Point(74, 205);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(93, 25);
            lblLadoC.TabIndex = 2;
            lblLadoC.Text = "Valor de C";
            // 
            // btnExecuta
            // 
            btnExecuta.Location = new Point(163, 306);
            btnExecuta.Name = "btnExecuta";
            btnExecuta.Size = new Size(112, 34);
            btnExecuta.TabIndex = 3;
            btnExecuta.Text = "Executar";
            btnExecuta.UseVisualStyleBackColor = true;
            btnExecuta.Click += btnExecuta_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(372, 306);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 4;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // txtLadoA
            // 
            txtLadoA.Location = new Point(227, 67);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(150, 31);
            txtLadoA.TabIndex = 5;
            txtLadoA.Validated += txtLadoA_Validated;
            // 
            // txtLadoB
            // 
            txtLadoB.Location = new Point(221, 138);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(150, 31);
            txtLadoB.TabIndex = 6;
            txtLadoB.Validated += txtLadoB_Validated;
            // 
            // txtLadoC
            // 
            txtLadoC.Location = new Point(221, 214);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(150, 31);
            txtLadoC.TabIndex = 7;
            txtLadoC.Validated += txtLadoC_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(956, 493);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoB);
            Controls.Add(txtLadoA);
            Controls.Add(btnSair);
            Controls.Add(btnExecuta);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private Button btnExecuta;
        private Button btnSair;
        private TextBox txtLadoA;
        private TextBox txtLadoB;
        private TextBox txtLadoC;
    }
}
