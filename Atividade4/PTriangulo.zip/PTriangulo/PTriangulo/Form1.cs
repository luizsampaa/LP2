namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (ladoA > Math.Abs(ladoB-ladoC) && ladoA < ladoB + ladoC
                && ladoB > Math.Abs(ladoB - ladoC) && ladoB < ladoA + ladoC &&
                ladoC > Math.Abs(ladoA- ladoB) && ladoC < ladoA + ladoB && 
                ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Seu Tri�ngulo � equil�tero!");
                }
                else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA)
                {
                    MessageBox.Show("Seu tri�ngulo � is�celes!");
                }
                else
                {
                    MessageBox.Show("Seu tri�ngulo � escaleno!");
                }
            }
            else
            {
                txtLadoA.Clear();
                txtLadoB.Clear();
                txtLadoC.Clear();
                MessageBox.Show("Triangulo Imposs�vel!");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                txtLadoA.Clear();
                MessageBox.Show("Lado A inv�lido!");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                txtLadoB.Clear();
                MessageBox.Show("Lado B inv�lido!");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                txtLadoC.Clear();
                MessageBox.Show("Lado C inv�lido!");
            }
        }
    }
}
