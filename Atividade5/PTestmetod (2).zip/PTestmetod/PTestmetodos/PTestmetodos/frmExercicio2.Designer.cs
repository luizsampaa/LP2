﻿namespace PTestmetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.btnIguais = new System.Windows.Forms.Button();
            this.btnIns = new System.Windows.Forms.Button();
            this.btnIns2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtP1
            // 
            this.txtP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP1.Location = new System.Drawing.Point(302, 119);
            this.txtP1.Margin = new System.Windows.Forms.Padding(4);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(292, 34);
            this.txtP1.TabIndex = 2;
            // 
            // txtP2
            // 
            this.txtP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2.Location = new System.Drawing.Point(302, 278);
            this.txtP2.Margin = new System.Windows.Forms.Padding(4);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(292, 34);
            this.txtP2.TabIndex = 3;
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblP2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2.Location = new System.Drawing.Point(380, 208);
            this.lblP2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(135, 31);
            this.lblP2.TabIndex = 4;
            this.lblP2.Text = "Palavra 2 ";
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblP1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1.Location = new System.Drawing.Point(380, 51);
            this.lblP1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(128, 31);
            this.lblP1.TabIndex = 5;
            this.lblP1.Text = "Palavra 1";
            this.lblP1.Click += new System.EventHandler(this.lblP1_Click);
            // 
            // btnIguais
            // 
            this.btnIguais.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnIguais.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIguais.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIguais.Location = new System.Drawing.Point(139, 365);
            this.btnIguais.Margin = new System.Windows.Forms.Padding(4);
            this.btnIguais.Name = "btnIguais";
            this.btnIguais.Size = new System.Drawing.Size(175, 62);
            this.btnIguais.TabIndex = 6;
            this.btnIguais.Text = "Verifica se sao iguais";
            this.btnIguais.UseVisualStyleBackColor = false;
            this.btnIguais.Click += new System.EventHandler(this.btnIguais_Click);
            // 
            // btnIns
            // 
            this.btnIns.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnIns.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIns.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.Location = new System.Drawing.Point(361, 365);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(175, 62);
            this.btnIns.TabIndex = 7;
            this.btnIns.Text = "Inserir";
            this.btnIns.UseVisualStyleBackColor = false;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // btnIns2
            // 
            this.btnIns2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnIns2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIns2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns2.Location = new System.Drawing.Point(583, 365);
            this.btnIns2.Margin = new System.Windows.Forms.Padding(4);
            this.btnIns2.Name = "btnIns2";
            this.btnIns2.Size = new System.Drawing.Size(175, 62);
            this.btnIns2.TabIndex = 8;
            this.btnIns2.Text = "Inserir *";
            this.btnIns2.UseVisualStyleBackColor = false;
            this.btnIns2.Click += new System.EventHandler(this.btnIns2_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(850, 554);
            this.Controls.Add(this.btnIns2);
            this.Controls.Add(this.btnIns);
            this.Controls.Add(this.btnIguais);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.txtP1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Button btnIguais;
        private System.Windows.Forms.Button btnIns;
        private System.Windows.Forms.Button btnIns2;
    }
}