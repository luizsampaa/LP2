﻿namespace PTestmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInvert = new System.Windows.Forms.Button();
            this.btnRem = new System.Windows.Forms.Button();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnInvert
            // 
            this.btnInvert.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnInvert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInvert.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvert.Location = new System.Drawing.Point(413, 377);
            this.btnInvert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInvert.Name = "btnInvert";
            this.btnInvert.Size = new System.Drawing.Size(175, 76);
            this.btnInvert.TabIndex = 14;
            this.btnInvert.Text = "Inverter Texto";
            this.btnInvert.UseVisualStyleBackColor = false;
            this.btnInvert.Click += new System.EventHandler(this.btnInvert_Click);
            // 
            // btnRem
            // 
            this.btnRem.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRem.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRem.Location = new System.Drawing.Point(161, 377);
            this.btnRem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRem.Name = "btnRem";
            this.btnRem.Size = new System.Drawing.Size(175, 76);
            this.btnRem.TabIndex = 13;
            this.btnRem.Text = "Remover Ocorrências do 1 no 2";
            this.btnRem.UseVisualStyleBackColor = false;
            this.btnRem.Click += new System.EventHandler(this.btnRem_Click);
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblP1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1.Location = new System.Drawing.Point(318, 79);
            this.lblP1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(128, 31);
            this.lblP1.TabIndex = 12;
            this.lblP1.Text = "Palavra 1";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblP2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2.Location = new System.Drawing.Point(318, 219);
            this.lblP2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(135, 31);
            this.lblP2.TabIndex = 11;
            this.lblP2.Text = "Palavra 2 ";
            // 
            // txtP2
            // 
            this.txtP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2.Location = new System.Drawing.Point(250, 287);
            this.txtP2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(292, 34);
            this.txtP2.TabIndex = 10;
            // 
            // txtP1
            // 
            this.txtP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP1.Location = new System.Drawing.Point(250, 148);
            this.txtP1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(292, 34);
            this.txtP1.TabIndex = 9;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(716, 570);
            this.Controls.Add(this.btnInvert);
            this.Controls.Add(this.btnRem);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.txtP1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInvert;
        private System.Windows.Forms.Button btnRem;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.TextBox txtP1;
    }
}