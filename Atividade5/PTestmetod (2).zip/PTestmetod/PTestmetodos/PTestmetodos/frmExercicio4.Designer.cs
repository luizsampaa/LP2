﻿namespace PTestmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContLetra = new System.Windows.Forms.Button();
            this.btnEspBranco = new System.Windows.Forms.Button();
            this.btnContN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(42, 129);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(643, 266);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.rchtxtFrase_TextChanged);
            // 
            // btnContLetra
            // 
            this.btnContLetra.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnContLetra.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContLetra.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContLetra.Location = new System.Drawing.Point(761, 345);
            this.btnContLetra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContLetra.Name = "btnContLetra";
            this.btnContLetra.Size = new System.Drawing.Size(175, 62);
            this.btnContLetra.TabIndex = 11;
            this.btnContLetra.Text = "Contar Letras";
            this.btnContLetra.UseVisualStyleBackColor = false;
            this.btnContLetra.Click += new System.EventHandler(this.btnContLetra_Click);
            // 
            // btnEspBranco
            // 
            this.btnEspBranco.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnEspBranco.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEspBranco.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspBranco.Location = new System.Drawing.Point(761, 231);
            this.btnEspBranco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEspBranco.Name = "btnEspBranco";
            this.btnEspBranco.Size = new System.Drawing.Size(175, 62);
            this.btnEspBranco.TabIndex = 10;
            this.btnEspBranco.Text = "Primeiro Espaço em branco";
            this.btnEspBranco.UseVisualStyleBackColor = false;
            this.btnEspBranco.Click += new System.EventHandler(this.btnEspBranco_Click);
            // 
            // btnContN
            // 
            this.btnContN.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnContN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContN.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContN.Location = new System.Drawing.Point(761, 118);
            this.btnContN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContN.Name = "btnContN";
            this.btnContN.Size = new System.Drawing.Size(175, 62);
            this.btnContN.TabIndex = 9;
            this.btnContN.Text = "Contar Numeros";
            this.btnContN.UseVisualStyleBackColor = false;
            this.btnContN.Click += new System.EventHandler(this.btnContN_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnContLetra);
            this.Controls.Add(this.btnEspBranco);
            this.Controls.Add(this.btnContN);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContLetra;
        private System.Windows.Forms.Button btnEspBranco;
        private System.Windows.Forms.Button btnContN;
    }
}