﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestmetodos
{
    public partial class frmExercicio5 : Form
    {
        double N1, N2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            int Num1 = Convert.ToInt32(N1);
            int Num2 = Convert.ToInt32(N2);

            Random random = new Random();
            int resultado = random.Next(Num1,Num2+1);

            string resul = resultado.ToString();

            MessageBox.Show(resul);
        }

        private void txtN2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtN2.Text, out N2))
            {
                MessageBox.Show("Apenas numeros.");
                txtN2.Focus();
            }
            else if (N2 < N1)
            {
                MessageBox.Show("numeros maiores que o Numero 1");
                txtN2.Focus();
            }
        }

        private void txtN1_Validating(object sender, CancelEventArgs e)
        {
            
            if(!double.TryParse(txtN1.Text, out N1))
            {
                MessageBox.Show("Apenas numeros.");
                txtN1.Focus();
            }
            else if (N1 <= 0)
            {
                MessageBox.Show("numeros maiores que  0.");
                txtN1.Focus();
            }        
        }
    }
}
