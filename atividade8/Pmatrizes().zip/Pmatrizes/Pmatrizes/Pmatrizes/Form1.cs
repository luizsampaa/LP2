﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º  número", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList minhalista = new ArrayList() {"Ana", "André", "Débora", "Fatima", "Joao", "Janete", "Otávio", "Marcelo", "Pedro"};
            minhalista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nomes in minhalista)
            {
                auxiliar += nomes + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double[] medias = new double[20];

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1}º do aluno {i + 1}.", "entrada de dados");


                    if (string.IsNullOrEmpty(auxiliar))
                    {
                        MessageBox.Show("Entrada invalida.");
                        break;
                    }
                    else if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Numero Invalido");
                        j--;
                    }

                }

                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    soma += notas[i, j];
                }
                medias[i] = soma / 3;
            }
            
            for (int i = 0; i < 20; i++)
            {
                MessageBox.Show($"A média do aluno {i + 1} é: {medias[i]:F2}");
            }
        }
        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 Exe4 = new frmExercicio4();
            Exe4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 Exe5 = new frmExercicio5();
            Exe5.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
